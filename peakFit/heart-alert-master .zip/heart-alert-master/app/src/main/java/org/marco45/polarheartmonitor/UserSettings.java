package org.marco45.polarheartmonitor;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
public class UserSettings extends Activity implements OnItemSelectedListener {
    private static UserSettings us = new UserSettings();
    private int maxRate;
    private int minRate;
    private static String username = "";
    private String weight;
    private String age;
    private String gender;

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // Do nothing
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                               long arg3) {

    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public static String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getMax() {

        return maxRate;
    }

    public int getMin() {

        return minRate;
    }

    public void setMaxRate(int maxRate) {
        this.maxRate = maxRate;
    }

    public void setMinRate(int minRate) {
        this.minRate = minRate;
    }
}
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************