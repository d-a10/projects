package org.marco45.polarheartmonitor;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethod;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
public class SettingsActivity extends Activity {

    UserSettings user = new UserSettings();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        EditText username = (EditText) findViewById(R.id.editText);
        EditText weight = (EditText) findViewById(R.id.editText2);
        EditText age = (EditText) findViewById(R.id.editText3);
        EditText gender = (EditText) findViewById(R.id.editText4);
        username.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                boolean handled = false;
                if (i == EditorInfo.IME_ACTION_NEXT) {
                    String inputText = textView.getText().toString();
                    user.setUsername(inputText);
                    Toast.makeText(SettingsActivity.this, "Your name is: "
                        + inputText, Toast.LENGTH_SHORT).show();
                }
                return handled;
            }
        });

        gender.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                  boolean handled = false;
                if (i == EditorInfo.IME_ACTION_DONE) {
                    String inputText4 = textView.getText().toString();
                    user.setGender(inputText4);
                    Toast.makeText(SettingsActivity.this, "Your gender is: "
                        + inputText4, Toast.LENGTH_SHORT).show();

                    InputMethodManager inputManager = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                            InputMethodManager.HIDE_NOT_ALWAYS);
                    handled = true;
                }

                return handled;
            }
        });


        weight.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                boolean handled = false;
                if (i == EditorInfo.IME_ACTION_NEXT) {
                    String inputText2 = textView.getText().toString();
                    user.setWeight(inputText2);
                    Toast.makeText(SettingsActivity.this, "Your weight is: "
                            + inputText2, Toast.LENGTH_SHORT).show();
                }

                return handled;
            }
        });

        age.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                boolean handled = false;
                if (i == EditorInfo.IME_ACTION_NEXT) {
                    String inputText3 = textView.getText().toString();
                    user.setAge(inputText3);
                    Toast.makeText(SettingsActivity.this, "Your age is: "
                            + inputText3, Toast.LENGTH_SHORT).show();
                }

                return handled;
            }
        });
    }

}
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************
