package org.marco45.polarheartmonitor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.PointLabelFormatter;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.SimpleXYSeries;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;


/**
 * This program connect to a bluetooth polar heart rate monitor and display data
 * @author Marco
 *
 */
public class MainActivity extends Activity implements OnItemSelectedListener, Observer {

	private int MAX_SIZE = 60; //graph max size
	boolean searchBt = true;
	BluetoothAdapter mBluetoothAdapter;
	List<BluetoothDevice> pairedDevices = new ArrayList<BluetoothDevice>();
	boolean menuBool = false; //display or not the disconnect option
	private XYPlot plot;
	Tracker t;//Set the Tracker
	boolean h7 = false; //Was the BTLE tested
	boolean normal = false; //Was the BT tested
	private Spinner spinner1;
	private SimpleXYSeries azimuthHistorySeries = null; //NEWNEWNEWNEW
	private SimpleXYSeries lowEndSeries = null;
	private Spinner maxSpinner;
	private Spinner minSpinner;
	UserSettings user = new UserSettings();
	boolean notifyFlag = false;
	/**
	 * ATTENTION: This was auto-generated to implement the App Indexing API.
	 * See https://g.co/AppIndexing/AndroidStudio for more information.
	 */
	private GoogleApiClient client;



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Log.i("Main Activity", "Starting Polar HR monitor main activity");
		DataHandler.getInstance().addObserver(this);
		AdView mAdView = (AdView) findViewById(R.id.adView);
		lowEndSeries = new SimpleXYSeries("MinSafeBPM");
		lowEndSeries.useImplicitXVals();
		azimuthHistorySeries = new SimpleXYSeries("MaxSafe"); //NEWNEWNEW
		azimuthHistorySeries.useImplicitXVals();			  //NEWNEWNEW



        // Create an ad request. Check logcat output for the hashed device ID to
        // get test ads on a physical device. e.g.
        // "Use AdRequest.Builder.addTestDevice("ABCDEF012345") to get test ads on this device."

		// Create an ad request. Check logcat output for the hashed device ID to
		// get test ads on a physical device. e.g.
		// "Use AdRequest.Builder.addTestDevice("ABCDEF012345") to get test ads on this device."
//        AdRequest adRequest = new AdRequest.Builder().build();

		// Start loading the ad in the background.
//        mAdView.loadAd(adRequest);


        //Verify if device is to old for BTLE
        if(	android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR2){

    		Log.i("Main Activity", "old device H7 disbled");
        	h7=true;
        }
        
        //verify if bluetooth device are enabled
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if(DataHandler.getInstance().newValue){
			//Verify if bluetooth if activated, if not activate it
			mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();    
			if (!mBluetoothAdapter.isEnabled()) {
				new AlertDialog.Builder(this)
				.setTitle(R.string.bluetooth)
				.setMessage(R.string.bluetoothOff)
				.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) { 
						mBluetoothAdapter.enable();
						try {Thread.sleep(2000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						listBT();
						listMax();
						listMin();
					}
				})
				.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) { 
						searchBt = false;
					}
				})
				.show();
			}
			else{
				listBT();
				listMax();
				listMin();
			}



			// Create Graph
			plot = (XYPlot) findViewById(R.id.dynamicPlot);
			if(plot.getSeriesSet().size()==0){
				Number[] series1Numbers = {};
				DataHandler.getInstance().setSeries1(new SimpleXYSeries(Arrays.asList(series1Numbers),SimpleXYSeries.ArrayFormat.Y_VALS_ONLY,"Heart Rate")); 
			}
			DataHandler.getInstance().setNewValue(false);

		}
		else
		{
			listBT();
			listMax();
			listMin();
			plot = (XYPlot) findViewById(R.id.dynamicPlot);

		}
//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
//This gets rid of the gray grid
		plot.getGraphWidget().getGridBackgroundPaint().setColor(Color.WHITE); //inside graph

//This gets rid of the black border (up to the graph) there is no black border around the labels
		plot.getBackgroundPaint().setColor(Color.parseColor("#191919"));

//This gets rid of the black behind the graph
		plot.getGraphWidget().getBackgroundPaint().setColor(Color.parseColor("#191919")); //border color

//With a new release of AndroidPlot you have to also set the border paint
		plot.getBorderPaint().setColor(Color.parseColor("#191919"));

		//LOAD Graph
		LineAndPointFormatter series1Format = new LineAndPointFormatter( Color.rgb(0, 0, 255), Color.rgb(200, 200, 200), null, null );
		LineAndPointFormatter series2Format = new LineAndPointFormatter( Color.rgb(255, 0, 0), Color.rgb(255, 0, 0), null, null );
		LineAndPointFormatter series3Format = new LineAndPointFormatter( Color.parseColor("#ff751a"), Color.parseColor("#ff751a"), null, null );
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************

		series1Format.setPointLabelFormatter(new PointLabelFormatter());
		plot.addSeries(azimuthHistorySeries, series2Format);
		plot.addSeries(lowEndSeries, series3Format);
		plot.addSeries(DataHandler.getInstance().getSeries1(), series1Format);
		plot.setTicksPerRangeLabel(3);
		plot.getGraphWidget().setDomainLabelOrientation(-45);

		//ANALYTIC
		t = GoogleAnalytics.getInstance(this).newTracker("UA-51478243-1");
		t.setScreenName("Polar main page");
		t.send(new HitBuilders.AppViewBuilder().build());

		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
		client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
	}

	@Override
	protected void onDestroy(){
		super.onDestroy();
		DataHandler.getInstance().deleteObserver(this);
	}

	public void onStart(){
//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
		TextView name = (TextView) findViewById(R.id.name);
		name.setText("Get Fit " + UserSettings.getUsername() + "!");
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************

		super.onStart();
		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
		client.connect();
		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
		Action viewAction = Action.newAction(
				Action.TYPE_VIEW, // TODO: choose an action type.
				"Main Page", // TODO: Define a title for the content shown.
				// TODO: If you have web page content that matches this app activity's content,
				// make sure this auto-generated web page URL is correct.
				// Otherwise, set the URL to null.
				Uri.parse("http://host/path"),
				// TODO: Make sure this auto-generated app deep link URI is correct.
				Uri.parse("android-app://org.marco45.polarheartmonitor/http/host/path")
		);
		AppIndex.AppIndexApi.start(client, viewAction);
	}

	/**
	 * Run on startup to list bluetooth paired device
	 */
	@SuppressWarnings("deprecation")
	@SuppressLint("NewApi")
	public void listBT(){
		Log.d("Main Activity", "Listing BT elements");
		if(searchBt){
			//Discover bluetooth devices
			final List<String> list = new ArrayList<String>();
			list.add("");
			pairedDevices.addAll(mBluetoothAdapter.getBondedDevices());
			// If there are paired devices
			if (pairedDevices.size() > 0) {
				// Loop through paired devices
				for (BluetoothDevice device : pairedDevices) {
					// Add the name and address to an array adapter to show in a ListView
					list.add(device.getName() + "\n" + device.getAddress());
				}
			}
			if(!h7){
				Log.d("Main Activity", "Listing BTLE elements");
				final BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {
				    @Override
				    public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord) {
				    	if(!list.contains(device.getName() + "\n" + device.getAddress())){
				    		Log.d("Main Activity", "Adding "+device.getName());
				    		list.add(device.getName() + "\n" + device.getAddress());
				    		pairedDevices.add(device);
				    	}
				    }
				};
				
				
				  Thread scannerBTLE = new Thread(){
					    public void run(){
				    		Log.d("Main Activity", "Starting scanning for BTLE");
					    	mBluetoothAdapter.startLeScan(leScanCallback);
					     try {
							Thread.sleep(5000);
				    		Log.d("Main Activity", "Stoping scanning for BTLE");
							mBluetoothAdapter.stopLeScan(leScanCallback);
						} catch (InterruptedException e) {
						}
					    }
					  };

					  scannerBTLE.start();
			}

//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
			//Populate drop down
			spinner1 = (Spinner) findViewById(R.id.spinner1);
			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, list);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner1.setOnItemSelectedListener(this);
			spinner1.setAdapter(dataAdapter);
			
			if(DataHandler.getInstance().getID()!=0 && DataHandler.getInstance().getID() < spinner1.getCount())
				spinner1.setSelection(DataHandler.getInstance().getID());
		}
	}

	// populate dropdown items for Set Max BPM
	public void listMax() {
		EditText setMax = (EditText) findViewById(R.id.setMax);
		setMax.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
				boolean handled = false;
				if (i == EditorInfo.IME_ACTION_DONE) {
					String inputText3 = textView.getText().toString();
					user.setMaxRate(Integer.parseInt(inputText3));
					Toast.makeText(MainActivity.this, "Your Max BPM is: "
							+ inputText3, Toast.LENGTH_SHORT).show();

					InputMethodManager inputManager = (InputMethodManager)
							getSystemService(Context.INPUT_METHOD_SERVICE);
					inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
							InputMethodManager.HIDE_NOT_ALWAYS);
					handled = true;

				}

				return handled;
			}
		});
	}

	// populate dropdown item for Set Min BPM
	public void listMin() {
		EditText setMin = (EditText) findViewById(R.id.setMin);
		setMin.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
				boolean handled = false;
				if (i == EditorInfo.IME_ACTION_DONE) {
					String inputText4 = textView.getText().toString();
					user.setMinRate(Integer.parseInt(inputText4));
					Toast.makeText(MainActivity.this, "Your Min BPM is: "
							+ inputText4, Toast.LENGTH_SHORT).show();

					InputMethodManager inputManager = (InputMethodManager)
							getSystemService(Context.INPUT_METHOD_SERVICE);
					inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
							InputMethodManager.HIDE_NOT_ALWAYS);
					handled = true;

				}

				return handled;
			}
		});
	}
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************

	/**
	 * When menu button are pressed
	 */
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		Log.d("Main Activity", "Menu pressed");
		if (id == R.id.action_settings) { //close connection		
			menuBool=false;
			Log.d("Main Activity", "disable pressed");
			if(spinner1!=null){
				spinner1.setSelection(0);
			}
			if(DataHandler.getInstance().getReader()==null)
			{
				Log.i("Main Activity", "Disabling h7");
				DataHandler.getInstance().getH7().cancel();
				DataHandler.getInstance().setH7(null);	
				h7=false;
			}
			else{
				Log.i("Main Activity", "Disabling BT");
				DataHandler.getInstance().getReader().cancel();
				DataHandler.getInstance().setReader(null);	
				normal=false;				
			}
			return true;
		}
		else if (id==R.id.about){ //about menu

			Log.i("Main Activity", "opening about");
			Intent intent = new Intent(this, AboutActivity.class);
			startActivity(intent);
		}
		else if (id==R.id.settings) { //settings menu
			Log.i("Main Activity", "opening settings");
			Intent intent2 = new Intent(this, SettingsActivity.class);
			startActivity(intent2);
		}
		return super.onOptionsItemSelected(item);
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/**
	 * When the option is selected in the dropdown we turn on the bluetooth
	 * Goes in here when any menu item selected
	 */
	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
		int maxBPM = user.getMax();
		int minBPM = user.getMin();

		// to get menu item as String - arg0.getSelectedItem().toString()
		if (arg0 == maxSpinner) {
			String str1 = arg0.getSelectedItem().toString();
			str1 = str1.replaceAll("[^\\d.]", "");
			maxBPM = Integer.parseInt(str1);
		}
		else if(arg0 == minSpinner) {
			String str2 = arg0.getSelectedItem().toString();
			str2 = str2.replaceAll("[^\\d.]", "");
			minBPM = Integer.parseInt(str2);
		}

		user.setMaxRate(maxBPM);
		user.setMinRate(minBPM);


		Log.i("YOUR MAX BPMs:", String.valueOf(user.getMax()));
		Log.i("YOUR MIN BPMs:", String.valueOf(user.getMin()));
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************
		if(arg2!=0){
			//Actual work
			DataHandler.getInstance().setID(arg2);
			if(!h7 && ((BluetoothDevice) pairedDevices.toArray()[DataHandler.getInstance().getID()-1]).getName().contains("H7") && DataHandler.getInstance().getReader()==null)
			{

				Log.i("Main Activity", "Starting h7");
				DataHandler.getInstance().setH7(new H7ConnectThread((BluetoothDevice) pairedDevices.toArray()[DataHandler.getInstance().getID()-1], this));
				h7=true;
			}
			else if (!normal && DataHandler.getInstance().getH7()==null){

				Log.i("Main Activity", "Starting normal");
				DataHandler.getInstance().setReader(new ConnectThread((BluetoothDevice) pairedDevices.toArray()[arg2-1], this));
				DataHandler.getInstance().getReader().start();
				normal=true;
			}
			menuBool=true;

		}

	}

	@Override
	public boolean onPrepareOptionsMenu (Menu menu) {
		menu.findItem(R.id.action_settings).setEnabled(menuBool);
		menu.findItem(R.id.action_settings).setVisible(menuBool);
		return true;
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {


	}

	/**
	 * Called when bluetooth connection failed
	 */
	public void connectionError(){

		Log.w("Main Activity", "Connection error occured");
		if(menuBool==true){//did not manually tried to disconnect
			Log.d("Main Activity", "in the app");
			menuBool=false;
			final MainActivity ac = this;
			runOnUiThread(new Runnable() {
				public void run() {
					Toast.makeText(getBaseContext(),getString(R.string.couldnotconnect),Toast.LENGTH_SHORT).show();
					//TextView rpm = (TextView) findViewById(R.id.rpm);
					//rpm.setText("0 BMP");
					Spinner spinner1 = (Spinner) findViewById(R.id.spinner1);
					if( DataHandler.getInstance().getID()< spinner1.getCount())
						spinner1.setSelection(DataHandler.getInstance().getID());
					
					if(h7==false){
	
						Log.w("Main Activity", "starting H7 after error");
						DataHandler.getInstance().setReader(null);
						DataHandler.getInstance().setH7(new H7ConnectThread((BluetoothDevice) pairedDevices.toArray()[DataHandler.getInstance().getID()-1], ac));
						h7=true;
					}
					else if(normal==false){
						Log.w("Main Activity", "Starting normal after error");
						DataHandler.getInstance().setH7(null);
						DataHandler.getInstance().setReader(new ConnectThread((BluetoothDevice) pairedDevices.toArray()[DataHandler.getInstance().getID()-1], ac));
						DataHandler.getInstance().getReader().start();
						normal=true;
					}
				}
			});
		}
	}

	@Override
	public void update(Observable observable, Object data) {
		receiveData();		
	}

	/**
	 * Update Gui with new value from receiver
	 */
	public void receiveData(){		
		//ANALYTIC
		//t.setScreenName("Polar Bluetooth Used");
		//t.send(new HitBuilders.AppViewBuilder().build());
//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************
		runOnUiThread(new Runnable() {
			public void run() {
				//menuBool=true;
				TextView rpm = (TextView) findViewById(R.id.rpm);
				rpm.setText(DataHandler.getInstance().getLastValue() + " BPM");

				if(DataHandler.getInstance().getLastValue()!=0){
					azimuthHistorySeries.addLast(null, user.getMax() /*GETMAX*/);
					lowEndSeries.addLast(null, user.getMin() /*GETLOW*/);
					DataHandler.getInstance().getSeries1().addLast(0, DataHandler.getInstance().getLastValue());
					if(DataHandler.getInstance().getSeries1().size()>MAX_SIZE){
						azimuthHistorySeries.removeFirst();
						lowEndSeries.removeFirst();
						DataHandler.getInstance().getSeries1().removeFirst();}//Prevent graph to overload data.
					plot.redraw();
				}

//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************

				TextView min = (TextView) findViewById(R.id.min);
				min.setText("Min " + DataHandler.getInstance().getMin() + " BPM");

				TextView avg = (TextView) findViewById(R.id.avg);
				avg.setText("Avg " + DataHandler.getInstance().getAvg() + " BPM");

				TextView max = (TextView) findViewById(R.id.max);
				max.setText("Max " + DataHandler.getInstance().getMax() + " BPM");

//*************************************************************************************************
// Start of Human Factor's group 10 code
//*************************************************************************************************



				//Make sounds if userMax HR is reached
				if (DataHandler.getInstance().getLastValue() > user.getMax()) {
					TextView status = (TextView) findViewById(R.id.status);
					status.setText("Too high");
					status.setTextColor(Color.parseColor("#ff3333"));

					TextView rpmColor = (TextView) findViewById(R.id.rpm);
					rpmColor.setTextColor(Color.parseColor("#ff3333"));

					if (!notifyFlag) {
						MediaPlayer praise = MediaPlayer.create(MainActivity.this, R.raw.schwarzenegger);
						praise.start();
						notifyFlag = true;
					}


				}
				//Make sounds if userMin HR is reached & HR threshold is reached
				else if (DataHandler.getInstance().getLastValue() < user.getMin() && DataHandler.getInstance().getMax() > user.getMin()) {
					TextView status = (TextView) findViewById(R.id.status);
					status.setText("Too Low");
					status.setTextColor(Color.parseColor("#ff751a"));

					TextView rpmColor = (TextView) findViewById(R.id.rpm);
					rpmColor.setTextColor(Color.parseColor("#ff751a"));

					if (!notifyFlag) {
						MediaPlayer insult = MediaPlayer.create(MainActivity.this, R.raw.grandma);
						// play a random insult
						Random rand = new Random();
						int n = rand.nextInt(6);


						switch (n) {
							case 0:
								insult = MediaPlayer.create(MainActivity.this, R.raw.jellyrolls);
								break;
							case 1:
								insult = MediaPlayer.create(MainActivity.this, R.raw.grandma);
								break;
							case 2:
								insult = MediaPlayer.create(MainActivity.this, R.raw.brolift);
								break;
							case 3:
								insult = MediaPlayer.create(MainActivity.this, R.raw.milkshake);
								break;
							case 4:
								insult = MediaPlayer.create(MainActivity.this, R.raw.pathetic);
								break;
							case 5:
								insult = MediaPlayer.create(MainActivity.this, R.raw.workingout);
								break;
							case 6:
								insult = MediaPlayer.create(MainActivity.this, R.raw.zombie);
								break;
						}

						insult.start();
						notifyFlag = true;
					}
				}
				else {
					TextView status = (TextView) findViewById(R.id.status);
					status.setText("Normal");
					status.setTextColor(Color.parseColor("#00b33c"));

					TextView rpmColor = (TextView) findViewById(R.id.rpm);
					rpmColor.setTextColor(Color.parseColor("#00b33c"));
					notifyFlag = false;
				}
//*************************************************************************************************
// End of Human Factor's group 10 code
//*************************************************************************************************
			}
		});
	}

	@Override
	public void onStop() {
		super.onStop();

		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
		Action viewAction = Action.newAction(
				Action.TYPE_VIEW, // TODO: choose an action type.
				"Main Page", // TODO: Define a title for the content shown.
				// TODO: If you have web page content that matches this app activity's content,
				// make sure this auto-generated web page URL is correct.
				// Otherwise, set the URL to null.
				Uri.parse("http://host/path"),
				// TODO: Make sure this auto-generated app deep link URI is correct.
				Uri.parse("android-app://org.marco45.polarheartmonitor/http/host/path")
		);
		AppIndex.AppIndexApi.end(client, viewAction);
		client.disconnect();
	}
}
