package org.marco45.polarheartmonitor;


import android.app.Activity;
import android.os.Bundle;
/**
 * About activy displaing info about the app
 * @author marco
 *
 */
public class AboutActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
	}
}
