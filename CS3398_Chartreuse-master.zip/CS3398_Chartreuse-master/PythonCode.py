from sys import argv

import xlrd
import xlwt

from xlrd.sheet import ctype_text

script, filename = argv

workbook = xlrd.open_workbook(filename, encoding_override = "cp1252")

worksheet = workbook.sheet_by_index(0)

row = worksheet.row(0)

# PROBLEM TO ADDRESS: Still continues even if "no"
inp = input("Do you want to view the spreadsheet? yes or no\n")

# Validates user input. Note: special characters still accepted as valid input.
while inp.isdigit():
   inp = input("Invalid input. Please try again. Input yes or no.\n")
print('\n')

if inp.lower() == 'yes' or 'y':

   print('(Column #)')
   for idx, cell_obj in enumerate(row):
      cell_type_str = ctype_text.get(cell_obj.ctype, 'unknown type') 
      if cell_obj.value != '':
         print('(%s) %s' % (idx, cell_obj))

   # Print all values, iterating through rows and columns
   num_cols = worksheet.ncols   # Number of columns
   for row_idx in range(0, worksheet.nrows):    # Iterate through rows
      print ('-'*40)
      print ('Row: %s' % row_idx)   # Print row number
      for col_idx in range(0, num_cols):  # Iterate through columns
         if worksheet.cell(row_idx,col_idx).value != '':
            cell_obj = worksheet.cell(row_idx, col_idx)  # Get cell object by row, col
            print ('Column: [%s] cell_obj: [%s]' % (col_idx, cell_obj))

   # Prints all column heading titles
   print('\n')
   print('(Column #)')
   for idx, cell_obj in enumerate(row):
       cell_type_str = ctype_text.get(cell_obj.ctype, 'unknown type')
       if cell_obj.value != '':
           print('(%s) %s' % (idx, cell_obj))

   inp2 = []  # empty array for user-desired columns
   flag = 1

   # Prompt user to enter column #s for desired data
   print("\nType and enter column # of data you wish to view and save to another file.")
   print("Otherwise, press any letter to exit.\n")
   inp1 = input("Enter single column #: ")

   # Ensure valid user input and add column #s to inp2[]
   while inp1.isdigit():
       if flag == 0:
           inp1 = input("Enter additional column # or press any letter to exit.\n")
       if inp1.isdigit():
           inp2.append(inp1)
       flag = 0
   print('\n')

   wb1 = xlwt.Workbook()
   sheet1 = wb1.add_sheet('Output')
   colcount = 0

   # Displays selected content from Excel workbook
   for i in inp2:
       num = int(i)
       print('Column: [%s] [#%s]\n' %(worksheet.cell(0,num),num))

       for row_idx in range(0,worksheet.nrows):
           if worksheet.cell(row_idx,num).value != '':
               print('Row: [%s] %s\n' % (row_idx,worksheet.cell(row_idx,num)))

       data = [worksheet.cell_value(row,num) for row in range(worksheet.nrows)]

       for index, value in enumerate(data):
           sheet1.write(index,colcount,value)

       colcount = colcount+1
       print('\n')

   # Prompt for choice to export data
   print('\n')
   print("The chosen column(s) will be printed to a file. Please choose which type.\n")
   inp3 = input("Press 1 to print Excel output file, 2 to print a text output file, or any other key to exit.\n")

   # Create and write data to Excel file
   if inp3 == '1':
       wb1.save('output.xls')

   # Create file and write data to text file
   if inp3 == '2':
      data2 = open('output.txt', 'w')

      for i in inp2:
         num = int(i)
         data = [worksheet.cell(row,num) for row in range(worksheet.nrows)]
         data2.write('Column: [%s] \n' % num)

         for index, value in enumerate(data):
            val = str(value)
            if(worksheet.cell(index,num).value != ''):
               data2.write('Row: [%s] ' %index)
               data2.write(val)
               data2.write('\n')

         data2.write('\n')

      data2.close()

print('\n')
